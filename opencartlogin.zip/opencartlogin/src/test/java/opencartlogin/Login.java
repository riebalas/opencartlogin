package opencartlogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;




import java.time.Duration;


public class Login {



    public static void main(String[] arg) {


        WebDriver driver = new ChromeDriver();
        String url = "https://demo.opencart.com/index.php?route=account/login&language=en-gb";
        driver.get(url);


        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("password"));



        emailField.sendKeys("techin123@gmail.com");
        passwordField.sendKeys("techin123");

        WebElement submitButton = driver.findElement(By.xpath("//button[text()='Login']"));

        submitButton.click();




        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='alert alert-success']")));


        if (successMessage.getText().contains("User account created successfully")) {
            System.out.println("Account creation successful!");

            System.out.println("Account creation failed.");
        } else {
            System.out.println("Account creation failed.");
        }

    }
}


